<?php 
include('header.php');
?>
<body>
 <div class="navbar  navbar-fixed-top">
    <div class="navbar-inner1">
.....
    </div>
    </div>
<div class="container">

<br>
<br>
<br>
<br>

   
<div class="thumbnail">
     <div class="row">
	<div class="span3 offset1">&reg;</div>
    <div class="span8">
	<br>
	
	<div class="alert alert-info"><strong><i class="icon-file"></i>&nbsp;FOURSQUARE GOSPEL CHURCH DATA ENTRY SYSTEM BY GABRIEL OKUGBE.</strong></div>
	
	 <form class="form-horizontal" method="POST">
    <div class="control-group">
    <label class="control-label" for="inputEmail">First Name</label>
    <div class="controls">
    <input type="text" class="span4" name="nt" id="inputEmail" placeholder="First Name" required>
    </div>
    </div>
	  <div class="control-group">
    <label class="control-label" for="inputEmail">Surname</label>
    <div class="controls">
    <input type="text" class="span4" name="np" id="inputEmail" placeholder="Surname" required>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail">Profession/Vocation</label>
    <div class="controls">
    <input type="text" class="span4" name="amount" id="inputEmail" placeholder="Profession" required>
    </div>
    </div>
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail">Experience(Year's)</label>
    <div class="controls">
    <input type="text" class="span4" name="tnum" id="inputEmail" placeholder="Year's of Experience" required>
    </div>
    </div>
	
	
	  <div class="control-group">
    <label class="control-label" for="inputEmail">Church Name</label>
    <div class="controls">
    <input type="text" class="span4" name="cn" id="inputEmail" placeholder="Church Name" required>
    </div>
    </div>
 
 	
	  <div class="control-group">
    <label class="control-label" for="inputEmail">Zone</label>
    <div class="controls">
    <input type="text" class="span4" name="zd" id="inputEmail" placeholder="Zone" required>
    </div>
    </div>
 
 	
	  <div class="control-group">
    <label class="control-label" for="inputEmail">Phone Number</label>
    <div class="controls">
    <input type="text" class="span4" name="pn" id="inputEmail" placeholder="Phone Number" required>
    </div>
    </div>
    
    	  <div class="control-group">
    <label class="control-label" for="inputEmail">Email Address</label>
    <div class="controls">
    <input type="text" class="span4" name="ea" id="inputEmail" placeholder="Email Address" required>
    </div>
    </div>
 
    <div class="control-group">
    <div class="controls">

    <button type="submit" name="submit" class="btn btn-success"><i class="icon-save icon-large"></i>&nbsp;Submit</button>
    </div>
    </div>
    </form>
	</div>
    <div class="span2">.</div>
    </div>
	</div>
	   <div class="navbar navbar-inverse">
    <div class="navbar-inner ">
   <center id="color_white">
	Gswapps
   </center>
    </div>
    </div>
	
	<?php
	if (isset($_POST['submit'])){
	$nt=$_POST['nt'];
	$np=$_POST['np'];
	$amount=$_POST['amount'];
	$tnum=$_POST['tnum'];
	$cn=$_POST['cn'];
	$zd=$_POST['zd'];
	$pn=$_POST['pn'];
	$ea=$_POST['ea'];
	
	mysql_query("insert into member (nt,np,amount,tnum,cn,zd,pn,ea,date)
	values('$nt','$np','$amount','$tnum','$cn','$zd','$pn','$ea',NOW())
	")or die(mysql_error());
	?>
	<script type="text/javascript">
	alert('You have Successfully Registered, Thank You');
	window.location="index.php";
	</script>

	<?php
	}
	?>
	
	
</div>
</body>
</html>