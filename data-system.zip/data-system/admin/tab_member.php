<div class="tab-pane fade in active" id="member">
   
<?php
                
                $excel = mysql_query("select  * from member")or die(mysql_error());
                $row = mysql_fetch_array($excel);
                $id_excel = $row['member_id'];
                ?>

                <form method="POST" action="excel.php">
                    <input type="hidden" name="id_excel" value="<?php echo $id_excel; ?>">
                    <button id="save_voter" class="btn btn-success" name="save"> Download Excel File</button>
                </form>
				
                        <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered" id="example">
                            <div class="alert alert-info">
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                <strong><i class="icon-user icon-large"></i>&nbsp;Registered Member</strong>
                           </div>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Surname</th>
                                    <th>Profession / Vocation</th>
                                    <th>Experience(Year's)</th>
                                    <th>Church Name</th>
                                    <th>Zone</th>
                                    <th>Phone Number</th>
                                    <th>Email Address</th>
                                    <th>Date</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
							<?php
							$query=mysql_query("select * from member")or die(mysql_error());
							while($row=mysql_fetch_array($query)){
							$id=$row['member_id'];
							?>
                              
                           		<tr class="del<?php echo $id ?>">
                                       <td><?php echo $row['nt']; ?></td>
                                       <td><?php echo $row['np']; ?></td>
                                       <td><?php echo $row['amount']; ?></td>
                                       <td><?php echo $row['tnum']; ?></td>
                                       <td><?php echo $row['cn']; ?></td>		
                                       <td><?php echo $row['zd']; ?></td>
                                       <td><?php echo $row['pn']; ?></td>
                                       <td><?php echo $row['ea']; ?></td>
                                       <td><?php echo $row['date']; ?></td>
                                       <td><a  id="<?php echo $id;?>" class="delete_member"><i class="icon-trash"></i>&nbsp;Delete</a></td>
                                </tr>
								<?php } ?>
                         
						 
                                
						 
						 
                            </tbody>
                        </table>
					
					
						<script type="text/javascript">
        $(document).ready( function() {

	
	
            $('.delete_member').click( function() {
		
                var id = $(this).attr("id");
         
                if(confirm("Are you sure you want to delete this Member?")){
                    $.ajax({
                        type: "POST",
                        url: "delete_member.php",
                        data: ({id: id}),
                        cache: false,
                        success: function(html){
                            $(".del"+id).fadeOut('slow'); 
                        } 
                    }); 
                }else{
                    return false;}
            });				
        });
    </script>


</div>