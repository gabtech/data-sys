<?php
mysql_select_db('mp_14058622_gpay',mysql_connect('sql100.my-place.us','mp_14058622','lab300'))or die(mysql_error());
?>